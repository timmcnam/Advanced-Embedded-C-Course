/*
  Timothy McNamara
  ECET 49900
  Lab 02
  Last Revised: 01/17/2024
*/

volatile unsigned char DetermineDecimalNum (volatile unsigned char);
volatile unsigned char DetermineAsciiVal (volatile unsigned char);