/*
  Timothy McNamara
  ECET 49900
  Lab 05
  Last Revised: 02/06/2024
*/

// Here lie the function prototypes. 
// There is only one and it returns and is passed nothing.
 
// void Traditional(void);
void HALLab(void);