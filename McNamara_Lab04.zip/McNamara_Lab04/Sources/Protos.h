/*
  Timothy McNamara
  ECET 49900
  Lab 04
  Last Revised: 01/30/2024
*/

// Here lie the function prototypes. 
// They both return and are passed nothing.
 
// void Traditional(void);
void Modern(void);