/*
  Timothy McNamara
  ECET 49900
  Lab 08
  Last Revised: 02/27/2024
*/

void Taillights(void);
void Delay(unsigned long);
void RTIInitial(void);
void RTIDelay(void);
void interrupt RTIServiceRout(void);