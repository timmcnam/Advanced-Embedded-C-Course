#include <hidef.h>      /* common defines and macros */
#include <stdio.h>
#include "derivative.h"      /* derivative-specific definitions */
#include "Protos.h"
#include "defs.h"

/*
  Timothy McNamara
  ECET 49900
  Lab 11
  Last Revised: 04/02/2024
*/

void TimerInitialize(void)
{
   ENABLE_INT;
   ENABLE_TIMER_ZERO;
   TIMER_ZERO_INTERRUPT_EN;
   TIMER_SYSTEM_EN;
   TIMER_ZERO_FLAG_RESET;
   TIMER_PRIMER;
   TIMER_ZERO_OL;
   TIMER_ZERO_OM;
}