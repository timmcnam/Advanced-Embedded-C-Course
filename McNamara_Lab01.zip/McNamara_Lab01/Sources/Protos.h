  /*
     Timothy McNamara
     ECET 49900
     Tuesday Lab
     Last Edited: 01/09/2023
  */
  
  void FillTable(void);
  int Fact(int);